package layerx

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"strconv"
	"strings"
	"sync/atomic"
	"testing"
)

func TestLayerXKeyAuthorizerIsExactAndRedactsNoAlternateGrammar(t *testing.T) {
	secret := "lxp_live_" + strings.Repeat("a", 64)
	authorizer, err := NewLayerXKeyAuthorizer("beta_key-1", secret)
	if err != nil {
		t.Fatalf("construct LayerX-Key authorizer: %v", err)
	}
	request, err := http.NewRequest(http.MethodPost, "https://example.invalid/v1/programs/call", bytes.NewReader(nil))
	if err != nil {
		t.Fatalf("construct request: %v", err)
	}
	if err := authorizer(request); err != nil {
		t.Fatalf("authorize request: %v", err)
	}
	if authorization := request.Header.Get("Authorization"); authorization != "LayerX-Key beta_key-1:"+secret || !validLayerXAuthorization(authorization) {
		t.Fatalf("unexpected Programs authorization grammar")
	}
	for _, invalid := range []string{
		"Bearer " + secret,
		"LayerX-Key beta_key-1:lxp_live_" + strings.Repeat("A", 64),
		"LayerX-Key beta key:" + secret,
		"LayerX-Key beta_key-1:" + strings.TrimSuffix(secret, "a"),
	} {
		if validLayerXAuthorization(invalid) {
			t.Fatalf("accepted invalid Programs authorization: %q", invalid)
		}
	}
}

func TestProgramAgentEnvelopeRequiresExactAchievedSequencerProof(t *testing.T) {
	encoded := []byte(`{"request_id":"request-1","value":{"state":"unknown"},"verification_status":{"state":"Achieved","level":"SequencerSigned"}}`)
	if _, err := decodeProgramAgentEnvelope(http.StatusOK, encoded, "program.call"); err == nil || err.Code != ErrorVerificationFailure {
		t.Fatalf("pending Programs result accepted achieved verification: %v", err)
	}
	pending := []byte(`{"request_id":"request-1","value":{"state":"unknown"},"verification_status":{"state":"Unverified","requested":"SequencerSigned","achieved":"Unverified","reason":"receipt_pending"}}`)
	value, err := decodeProgramAgentEnvelope(http.StatusAccepted, pending, "program.call")
	if err != nil || string(value) != `{"state":"unknown"}` {
		t.Fatalf("decode exact pending Programs success: value=%s error=%v", value, err)
	}
	discovery := []byte(`{"request_id":"request-2","value":{"program_id":"` + strings.Repeat("a", 64) + `"},"verification_status":{"state":"Unverified","requested":"SequencerSigned","achieved":"Unverified","reason":"server_side_receipt_verification_only"}}`)
	if _, err := decodeProgramAgentEnvelope(http.StatusOK, discovery, "program.discover"); err != nil {
		t.Fatalf("server-attested discovery envelope was refused: %v", err)
	}
	terminal := []byte(`{"request_id":"request-3","value":{"state":"executed"},"verification_status":{"state":"Achieved","level":"SequencerSigned"}}`)
	if _, err := decodeProgramAgentEnvelope(http.StatusOK, terminal, "program.call"); err != nil {
		t.Fatalf("terminal Programs envelope was refused: %v", err)
	}
	for _, invalid := range [][]byte{
		[]byte(`{"request_id":"request-1","value":{},"verification_status":{"state":"Unverified","level":"SequencerSigned"}}`),
		[]byte(`{"request_id":"request-1","value":{},"verification_status":{"state":"Achieved","level":"StateProven"}}`),
		[]byte(`{"request_id":"request-1","value":{},"verification_status":{"state":"Achieved","level":"SequencerSigned"},"extra":true}`),
	} {
		if _, failure := decodeProgramAgentEnvelope(http.StatusOK, invalid, "program.simulate"); failure == nil || (failure.Code != ErrorDecodeFailure && failure.Code != ErrorVerificationFailure) {
			t.Fatalf("accepted invalid Programs success envelope: %s", invalid)
		}
	}
	errorEnvelope := []byte(`{"class":"CoreRejection","protocol_result_code":-7,"retriability":"Terminal","request_id":"request-2","reason":"core_refused"}`)
	if _, failure := decodeProgramAgentEnvelope(http.StatusBadRequest, errorEnvelope, "program.call"); failure == nil || failure.Code != ErrorCoreRejection || failure.Retry != RetryNever || failure.RequestID != "request-2" || failure.ProtocolResultCode == nil || *failure.ProtocolResultCode != -7 {
		t.Fatalf("decode exact Programs error envelope: %#v", failure)
	}
}

func TestProgramCallKeyAndUnknownSubmissionAreExact(t *testing.T) {
	keyText := strings.Repeat("a", 64)
	key, err := NewIdempotencyKey(keyText)
	if err != nil || !canonicalProgramKey(key) {
		t.Fatalf("canonical Programs key was refused: %v", err)
	}
	uppercase, err := NewIdempotencyKey(strings.Repeat("A", 64))
	if err != nil || canonicalProgramKey(uppercase) {
		t.Fatalf("uppercase Programs key was accepted")
	}
	activityText := strings.Repeat("b", 64)
	retained := []byte{0x01, 0x02, 0x03}
	raw := json.RawMessage(`{"state":"unknown","activity_id":"` + activityText + `","idempotency_key":"` + keyText + `","retained_signed_activity":"010203"}`)
	trusted := [32]byte{1}
	submission, decodeError := decodeProgramSubmission(raw, nil, nil, keyText, retained, trusted)
	if decodeError != nil || submission.State != ProgramSubmissionUnknown || submission.IdempotencyKey != keyText || !bytes.Equal(submission.RetainedSignedActivity, retained) {
		t.Fatalf("decode exact unknown Programs submission: %#v %v", submission, decodeError)
	}
	withExecution := json.RawMessage(`{"state":"unknown","activity_id":"` + activityText + `","idempotency_key":"` + keyText + `","retained_signed_activity":"010203","receipt":"00"}`)
	if _, decodeError := decodeProgramSubmission(withExecution, nil, nil, keyText, retained, trusted); decodeError == nil || decodeError.(*SDKError).Code != ErrorDecodeFailure {
		t.Fatalf("unknown Programs submission accepted execution evidence")
	}
	resolution := json.RawMessage(`{"state":"unknown","activity_id":"` + activityText + `","idempotency_key":"` + keyText + `"}`)
	if _, decodeError := decodeProgramSubmission(resolution, nil, nil, keyText, nil, trusted); decodeError != nil {
		t.Fatalf("receipt/activity resolution refused unknown state without retained request: %v", decodeError)
	}
	if _, decodeError := decodeProgramSubmission(resolution, nil, nil, keyText, retained, trusted); decodeError == nil || decodeError.(*SDKError).Code != ErrorVerificationFailure {
		t.Fatalf("submit accepted unknown state without retained signed activity")
	}
}

func TestProgramUsageRequiresNumericOutputValues(t *testing.T) {
	valid := json.RawMessage(`{"cpu_fuel":"1","memory_bytes":"2","storage_read_bytes":"3","storage_write_bytes":"4","output_values":5,"output_bytes":"6","fee_units":"7"}`)
	var usage ProgramUsage
	if decodeStrict(valid, &usage) != nil || usage.OutputValues != 5 || !validProgramUsage(usage) {
		t.Fatalf("numeric Programs output_values was refused: %#v", usage)
	}
	encodedString := bytes.Replace(valid, []byte(`"output_values":5`), []byte(`"output_values":"5"`), 1)
	if decodeStrict(encodedString, &usage) == nil {
		t.Fatalf("string Programs output_values was accepted")
	}
}

func TestProgramSourceTagsAreClosed(t *testing.T) {
	var unpublished ProgramSource
	if err := json.Unmarshal([]byte(`{"status":"unpublished"}`), &unpublished); err != nil || unpublished.Status != "unpublished" {
		t.Fatalf("decode unpublished source: %#v %v", unpublished, err)
	}
	verifiedJSON := `{"status":"verified","source_digest":"` + strings.Repeat("1", 64) + `","environment_digest":"` + strings.Repeat("2", 64) + `","pipeline":"sha256-source-artifact-reproducible-build-v1"}`
	var verified ProgramSource
	if err := json.Unmarshal([]byte(verifiedJSON), &verified); err != nil || verified.Status != "verified" || verified.SourceDigest == nil || verified.EnvironmentDigest == nil {
		t.Fatalf("decode verified source: %#v %v", verified, err)
	}
	for _, invalid := range []string{
		`{"status":"imagined"}`,
		`{"status":"unpublished","source_digest":"` + strings.Repeat("1", 64) + `"}`,
		strings.Replace(verifiedJSON, "sha256-source-artifact-reproducible-build-v1", "untrusted-pipeline", 1),
	} {
		var source ProgramSource
		if json.Unmarshal([]byte(invalid), &source) == nil {
			t.Fatalf("accepted invalid Programs source: %s", invalid)
		}
	}
}

func TestPendingProgramSubmissionNormalizesToUnknown(t *testing.T) {
	activity := [32]byte{1}
	key := strings.Repeat("02", 32)
	raw := json.RawMessage(`{"state":"pending","activity_id":"` + hex.EncodeToString(activity[:]) + `","idempotency_key":"` + key + `"}`)
	submission, err := decodeProgramSubmission(raw, nil, &activity, key, nil, [32]byte{3})
	if err != nil || submission.State != ProgramSubmissionUnknown || submission.ActivityID != activity || submission.IdempotencyKey != key {
		t.Fatalf("pending Programs submission was not retained as unknown: %#v %v", submission, err)
	}
}

func TestSignedProgramCallBindingDerivesCanonicalIdentityAndKey(t *testing.T) {
	call, key, activity := canonicalProgramCallFixture()
	binding, err := bindSignedProgramCall(call)
	if err != nil {
		t.Fatalf("bind canonical signed Programs call: %v", err)
	}
	if binding.IdempotencyKey != key || binding.ActivityID != domainDigest([]byte("LXP/v1/activity-id\x00"), activity) || binding.NotBefore != 1 || binding.NotAfter != 2 {
		t.Fatalf("signed Programs identity binding diverged")
	}
	mutated := call
	mutated.Calldata = []byte{0xaa, 0xbc}
	if _, err := bindSignedProgramCall(mutated); err == nil {
		t.Fatalf("signed Programs call accepted a different typed payload")
	}
	corrupted := call
	corrupted.SignedActivity = append([]byte(nil), call.SignedActivity...)
	corrupted.SignedActivity[len(corrupted.SignedActivity)-1] ^= 1
	corruptedBinding, err := bindSignedProgramCall(corrupted)
	if err != nil || corruptedBinding.ActivityID == binding.ActivityID {
		t.Fatalf("canonical signed bytes did not exclusively determine activity identity")
	}
}

func TestProgramDiscoveryCachesFreshHeadAndDowngradesServerClaim(t *testing.T) {
	program := [32]byte{1}
	id := hex.EncodeToString(program[:])
	var requests atomic.Uint64
	server := httptest.NewServer(http.HandlerFunc(func(response http.ResponseWriter, request *http.Request) {
		requests.Add(1)
		writeProgramSuccess(response, programDiscoveryValue(id, strings.Repeat("4", 64), 7, 900, 1_100), false)
	}))
	defer server.Close()
	programs := newHTTPProgramsForTest(t, server, [32]byte{9}, func() uint64 { return 1_000 })
	// Decision 808 retires HTTP discovery, including its server-attested head.
	if discovery, err := programs.Discover(context.Background(), program); programErrorCode(err) != ErrorUnavailableCapability || discovery.ProgramID != "" || discovery.Verification != "" {
		t.Fatalf("retired HTTP discovery returned a trusted projection: %+v %v", discovery, err)
	}
	if _, found := programs.rememberedHead(program); found || requests.Load() != 0 {
		t.Fatal("retired HTTP discovery dispatched or retained a server claim")
	}
	head := programHeadObservation{StateRoot: [32]byte{4}, Sequence: 7, ObservedAt: 900, ValidThrough: 1_100}
	if err := programs.rememberHead(program, head); err != nil || !programs.headIsCurrent(program, head) || !validProgramHeadTime(head, 1_000) {
		t.Fatalf("fresh head was not retained: %v", err)
	}
	rollback := head
	rollback.Sequence--
	if err := programs.rememberHead(program, rollback); err == nil {
		t.Fatal("head cache accepted a sequence rollback")
	}
	conflict := head
	conflict.StateRoot[0] ^= 1
	if err := programs.rememberHead(program, conflict); err == nil {
		t.Fatal("head cache accepted a conflicting root")
	}
	if validProgramHeadTime(head, 800) || !programs.headIsCurrent(program, head) {
		t.Fatal("future-observed head accepted or refused updates changed the retained head")
	}
}

func TestProgramsSimulateRejectsHeadExpiryDuringHTTPCall(t *testing.T) {
	call := programEVMCall(t, readProgramEVMVector(t, "native-program-call-v4"))
	var now, requests atomic.Uint64
	now.Store(1)
	server := httptest.NewServer(http.HandlerFunc(func(response http.ResponseWriter, request *http.Request) {
		requests.Add(1)
		now.Store(3)
		writeProgramSuccess(response, `{}`, true)
	}))
	defer server.Close()
	programs := newHTTPProgramsForTest(t, server, [32]byte{9}, func() uint64 { return now.Load() })
	head := programHeadObservation{StateRoot: [32]byte{4}, Sequence: 7, ObservedAt: 1, ValidThrough: 2}
	if err := programs.rememberHead(call.ProgramID, head); err != nil {
		t.Fatal(err)
	}
	if _, err := programs.Discover(context.Background(), call.ProgramID); programErrorCode(err) != ErrorUnavailableCapability {
		t.Fatalf("retired HTTP discovery was accepted: %v", err)
	}
	if simulation, err := programs.Simulate(context.Background(), call); programErrorCode(err) != ErrorUnavailableCapability || simulation.Committed || simulation.Execution.Receipt != "" {
		t.Fatalf("retired HTTP simulation returned evidence: %+v %v", simulation, err)
	}
	if requests.Load() != 0 || now.Load() != 1 || !programs.headIsCurrent(call.ProgramID, head) {
		t.Fatal("retired HTTP simulation dispatched or changed its retained head")
	}
	if !validProgramHeadTime(head, 1) || validProgramHeadTime(head, 3) {
		t.Fatal("head expiry was not enforced")
	}
}

func TestProgramsSimulateRejectsExpiredHeadBeforeHTTPCall(t *testing.T) {
	call := programEVMCall(t, readProgramEVMVector(t, "native-program-call-v4"))
	var now, requests atomic.Uint64
	now.Store(1)
	server := httptest.NewServer(http.HandlerFunc(func(response http.ResponseWriter, request *http.Request) {
		requests.Add(1)
		writeProgramSuccess(response, `{}`, true)
	}))
	defer server.Close()
	programs := newHTTPProgramsForTest(t, server, [32]byte{9}, func() uint64 { return now.Load() })
	head := programHeadObservation{StateRoot: [32]byte{4}, Sequence: 7, ObservedAt: 1, ValidThrough: 2}
	if err := programs.rememberHead(call.ProgramID, head); err != nil {
		t.Fatal(err)
	}
	now.Store(3)
	if validProgramHeadTime(head, now.Load()) {
		t.Fatal("expired head accepted before dispatch")
	}
	if simulation, err := programs.Simulate(context.Background(), call); programErrorCode(err) != ErrorUnavailableCapability || simulation.Committed || simulation.Execution.Receipt != "" {
		t.Fatalf("retired HTTP simulation returned evidence against an expired head: %+v %v", simulation, err)
	}
	if requests.Load() != 0 || !programs.headIsCurrent(call.ProgramID, head) {
		t.Fatal("retired HTTP simulation dispatched or changed its retained head")
	}
}

func TestProgramsSimulateRejectsConcurrentHTTPHeadAdvance(t *testing.T) {
	call := programEVMCall(t, readProgramEVMVector(t, "native-program-call-v4"))
	var requests atomic.Uint64
	server := httptest.NewServer(http.HandlerFunc(func(response http.ResponseWriter, request *http.Request) {
		requests.Add(1)
		writeProgramSuccess(response, `{}`, true)
	}))
	defer server.Close()
	programs := newHTTPProgramsForTest(t, server, [32]byte{9}, func() uint64 { return 1 })
	head := programHeadObservation{StateRoot: [32]byte{4}, Sequence: 7, ObservedAt: 1, ValidThrough: 2}
	if err := programs.rememberHead(call.ProgramID, head); err != nil {
		t.Fatal(err)
	}
	result := make(chan error, 1)
	go func() {
		simulation, err := programs.Simulate(context.Background(), call)
		if simulation.Committed || simulation.Execution.Receipt != "" {
			t.Error("retired HTTP simulation returned execution evidence")
		}
		result <- err
	}()
	advanced := head
	advanced.Sequence++
	advanced.StateRoot[0]++
	if err := programs.rememberHead(call.ProgramID, advanced); err != nil {
		t.Fatalf("advance Programs head: %v", err)
	}
	if err := <-result; programErrorCode(err) != ErrorUnavailableCapability {
		t.Fatalf("retired HTTP simulation accepted evidence during a head advance: %v", err)
	}
	if requests.Load() != 0 || programs.headIsCurrent(call.ProgramID, head) || !programs.headIsCurrent(call.ProgramID, advanced) {
		t.Fatal("retired HTTP simulation dispatched or failed to retain the head advance")
	}
}

func newHTTPProgramsForTest(t *testing.T, server *httptest.Server, key [32]byte, clock func() uint64) *Programs {
	t.Helper()
	transport, err := NewHumanHTTPTransport(server.URL, server.Client(), nil)
	if err != nil {
		t.Fatalf("construct Programs HTTP transport: %v", err)
	}
	client, err := NewClient(transport, nil)
	if err != nil {
		t.Fatalf("construct Programs client: %v", err)
	}
	programs, err := NewProgramsWithTrustOptions(client, key, ProgramTrustOptions{
		ClockMilliseconds: clock, MaximumSimulationAgeMilliseconds: 300,
	})
	if err != nil {
		t.Fatalf("construct Programs operations: %v", err)
	}
	return programs
}

func programDiscoveryValue(id string, root string, sequence uint64, observedAt uint64, validThrough uint64) string {
	return `{"program_id":"` + id + `","lifecycle":"active","version":1,"code_hash":"` + strings.Repeat("2", 64) +
		`","abi_version":2,"receipt_digest":"` + strings.Repeat("3", 64) + `","state_root":"` + root +
		`","observed_sequence":"` + strconv.FormatUint(sequence, 10) + `","observed_at":"` + strconv.FormatUint(observedAt, 10) +
		`","valid_through":"` + strconv.FormatUint(validThrough, 10) + `","verification":"registry-receipt-and-current-head-verified"}`
}

func writeProgramSuccess(response http.ResponseWriter, value string, achieved bool) {
	response.Header().Set("Content-Type", "application/json")
	verification := `{"state":"Unverified","requested":"SequencerSigned","achieved":"Unverified","reason":"server_side_receipt_verification_only"}`
	if achieved {
		verification = `{"state":"Achieved","level":"SequencerSigned"}`
	}
	_, _ = response.Write([]byte(`{"request_id":"request-1","value":` + value + `,"verification_status":` + verification + `}`))
}

func programErrorCode(err error) ErrorCode {
	if sdkError, ok := err.(*SDKError); ok {
		return sdkError.Code
	}
	return ""
}

func TestProgramSimulationEvidenceBindsWindowAgeAndDiscoveredHead(t *testing.T) {
	execution, evidence, binding, prior, publicKey := programSimulationEvidenceFixture(1_000)
	if err := verifySimulationEvidence(execution, evidence, binding, prior, publicKey, 1_000, 300); err != nil {
		t.Fatalf("canonical Programs simulation evidence was refused: %v", err)
	}
	for name, mutate := range map[string]func(*ProgramExecutionDocument, *ProgramSimulationEvidence, *programCallBinding, *programHeadObservation, *uint64, *uint64){
		"before signed window": func(execution *ProgramExecutionDocument, evidence *ProgramSimulationEvidence, binding *programCallBinding, prior *programHeadObservation, now *uint64, maximumAge *uint64) {
			*execution, *evidence, *binding, *prior, _ = programSimulationEvidenceFixture(899)
		},
		"after signed window": func(execution *ProgramExecutionDocument, evidence *ProgramSimulationEvidence, binding *programCallBinding, prior *programHeadObservation, now *uint64, maximumAge *uint64) {
			*execution, *evidence, *binding, *prior, _ = programSimulationEvidenceFixture(2_001)
			*now = 2_001
		},
		"future observation": func(_ *ProgramExecutionDocument, _ *ProgramSimulationEvidence, _ *programCallBinding, _ *programHeadObservation, now *uint64, _ *uint64) {
			*now = 999
		},
		"over age": func(_ *ProgramExecutionDocument, _ *ProgramSimulationEvidence, _ *programCallBinding, _ *programHeadObservation, now *uint64, maximumAge *uint64) {
			*now, *maximumAge = 1_301, 300
		},
		"wrong head root": func(_ *ProgramExecutionDocument, _ *ProgramSimulationEvidence, _ *programCallBinding, prior *programHeadObservation, _ *uint64, _ *uint64) {
			prior.StateRoot[0] ^= 1
		},
		"wrong head sequence": func(_ *ProgramExecutionDocument, _ *ProgramSimulationEvidence, _ *programCallBinding, prior *programHeadObservation, _ *uint64, _ *uint64) {
			prior.Sequence--
		},
		"expired head": func(_ *ProgramExecutionDocument, _ *ProgramSimulationEvidence, _ *programCallBinding, prior *programHeadObservation, _ *uint64, _ *uint64) {
			prior.ValidThrough = 999
		},
	} {
		t.Run(name, func(t *testing.T) {
			candidateExecution, candidateEvidence := execution, evidence
			candidateBinding, candidatePrior := binding, prior
			now, maximumAge := uint64(1_000), uint64(300)
			mutate(&candidateExecution, &candidateEvidence, &candidateBinding, &candidatePrior, &now, &maximumAge)
			if err := verifySimulationEvidence(candidateExecution, candidateEvidence, candidateBinding, candidatePrior, publicKey, now, maximumAge); err == nil {
				t.Fatal("invalid Programs simulation evidence was accepted")
			}
		})
	}
}

func TestProgramExecutionAuthorityRejectsWrongPinnedKey(t *testing.T) {
	publicKey := [32]byte{9}
	execution := ProgramExecutionDocument{Authority: ProgramResponseAuthority{
		BatchID: strings.Repeat("1", 64), Asset: strings.Repeat("2", 64),
		PreviousStateRoot: strings.Repeat("3", 64), ResultingStateRoot: strings.Repeat("4", 64),
		SequencerPublicKey: hex.EncodeToString(publicKey[:]),
	}}
	for name, pinned := range map[string][32]byte{"zero": {}, "different": {8}} {
		t.Run(name, func(t *testing.T) {
			if _, err := verifyExecutionAuthority(execution, pinned); err == nil {
				t.Fatal("Programs execution accepted authority outside the pinned sequencer key")
			}
		})
	}
	raw, err := json.Marshal(map[string]any{
		"state": "executed", "activity_id": strings.Repeat("a", 64), "program_id": strings.Repeat("b", 64),
		"guest_abi_version": 1, "module_version": 1, "batch_id": strings.Repeat("1", 64),
		"global_sequence": "1", "result_code": 0, "state_root": strings.Repeat("4", 64),
		"receipt": "00", "receipt_digest": strings.Repeat("5", 64), "terminal_payload": "", "call_graph": "00",
		"authority": execution.Authority,
		"usage": map[string]any{"cpu_fuel": "0", "memory_bytes": "0", "storage_read_bytes": "0",
			"storage_write_bytes": "0", "output_values": 0, "output_bytes": "0", "fee_units": "0"},
		"outcome":      map[string]any{"kind": "completed", "code": 0, "response": ""},
		"verification": "receipt-terminal-and-call-graph-verified", "idempotency_key": strings.Repeat("c", 64),
	})
	if err != nil {
		t.Fatalf("encode wrong-authority Programs submission: %v", err)
	}
	if _, err := decodeProgramSubmission(raw, nil, nil, strings.Repeat("c", 64), nil, [32]byte{8}); programErrorCode(err) != ErrorVerificationFailure {
		t.Fatalf("Programs submission accepted a response outside the pinned sequencer key: %v", err)
	}
}

func programSimulationEvidenceFixture(observedAt uint64) (ProgramExecutionDocument, ProgramSimulationEvidence, programCallBinding, programHeadObservation, [32]byte) {
	seed := [32]byte{7}
	privateKey := ed25519.NewKeyFromSeed(seed[:])
	var publicKey [32]byte
	copy(publicKey[:], privateKey.Public().(ed25519.PublicKey))
	activity, previous, hypothetical := [32]byte{1}, [32]byte{2}, [32]byte{3}
	boundary := sha256.Sum256(append([]byte("LayerX/emulator/simulation-boundary/v1\x00"), publicKey[:]...))
	sequence := uint64(10)
	signed := append([]byte("LayerX/agent/program-simulation-evidence/v1\x00"), boundary[:]...)
	signed = append(signed, activity[:]...)
	signed = append(signed, previous[:]...)
	signed = append(signed, hypothetical[:]...)
	var integer [8]byte
	binary.BigEndian.PutUint64(integer[:], sequence)
	signed = append(signed, integer[:]...)
	binary.BigEndian.PutUint64(integer[:], observedAt)
	signed = append(signed, integer[:]...)
	signed = append(signed, 0)
	digest := sha256.Sum256(signed)
	signature := ed25519.Sign(privateKey, digest[:])
	execution := ProgramExecutionDocument{
		ActivityID: hex.EncodeToString(activity[:]), StateRoot: hex.EncodeToString(hypothetical[:]),
		GlobalSequence: "11", Verification: "receipt-terminal-and-call-graph-verified",
		Authority: ProgramResponseAuthority{
			BatchID: strings.Repeat("4", 64), Asset: strings.Repeat("5", 64),
			PreviousStateRoot: hex.EncodeToString(previous[:]), ResultingStateRoot: hex.EncodeToString(hypothetical[:]),
			SequencerPublicKey: hex.EncodeToString(publicKey[:]),
		},
	}
	evidence := ProgramSimulationEvidence{
		BoundaryID: hex.EncodeToString(boundary[:]), ActivityID: hex.EncodeToString(activity[:]),
		PreviousStateRoot: hex.EncodeToString(previous[:]), HypotheticalStateRoot: hex.EncodeToString(hypothetical[:]),
		ObservedSequence: "10", ObservedAt: strconv.FormatUint(observedAt, 10), PublicKey: hex.EncodeToString(publicKey[:]),
		Signature: hex.EncodeToString(signature),
	}
	return execution, evidence,
		programCallBinding{ActivityID: activity, NotBefore: 900, NotAfter: 2_000},
		programHeadObservation{StateRoot: previous, Sequence: sequence, ObservedAt: 800, ValidThrough: 3_000},
		publicKey
}

func TestCanonicalProgramTerminalBindsResponseUsageAndGraph(t *testing.T) {
	program := [32]byte{1}
	graph := []byte{0x10, 0x20}
	terminal := []byte("LXP/program-execution/v4\x00")
	terminal = appendUint16(terminal, 1)
	terminal = appendUint32(terminal, 1)
	terminal = appendUint32(terminal, 1)
	terminal = appendUint64(terminal, 0)
	for _, value := range []uint64{1, 2, 3, 4} {
		terminal = appendUint64(terminal, value)
	}
	terminal = appendUint32(terminal, 5)
	terminal = appendUint64(terminal, 6)
	terminal = append(terminal, make([]byte, 15)...)
	terminal = append(terminal, 7)
	terminal = append(terminal, 0)
	terminal = append(terminal, program[:]...)
	terminal = appendUint16(terminal, 2)
	terminal = append(terminal, 0)
	terminal = appendUint32(terminal, 0)
	terminal = appendUint64(terminal, 2)
	terminal = append(terminal, 0xaa, 0xbb)
	terminal = appendUint64(terminal, uint64(len(graph)))
	terminal = append(terminal, graph...)
	projection, err := decodeProgramTerminal(1, 2, terminal, program, 0)
	if err != nil || !projection.Candidate || !projection.Successful || projection.Outcome.Kind != "completed" || !bytes.Equal(projection.Outcome.Response, []byte{0xaa, 0xbb}) || projection.OutputValues != 5 || projection.OutputBytes != 6 || projection.FeeUnits != NewUint128(0, 7) || !bytes.Equal(projection.EmbeddedGraph, graph) {
		t.Fatalf("canonical Programs terminal projection diverged: %#v %v", projection, err)
	}
	if _, err := decodeProgramTerminal(2, 2, terminal, program, -1); err == nil {
		t.Fatalf("Programs success terminal accepted failure receipt kind")
	}
}

func TestProgramTransferAuthorizationRecomputesCanonicalRoot(t *testing.T) {
	authorization, root := canonicalProgramTransferAuthorizationFixture()
	if err := verifyProgramTransferAuthorization(authorization, root); err != nil {
		t.Fatalf("canonical Programs transfer authorization rejected: %v", err)
	}
	mutated := append([]byte(nil), authorization...)
	mutated[len(mutated)-33] ^= 1
	if err := verifyProgramTransferAuthorization(mutated, root); err == nil {
		t.Fatalf("mutated Programs transfer authorization retained the signed root")
	}
	if err := verifyProgramTransferAuthorization(append(authorization, 0), root); err == nil {
		t.Fatalf("Programs transfer authorization accepted trailing bytes")
	}
}

func TestProgramOccupancySettlementBindsCountersFeesAndAssetRoot(t *testing.T) {
	asset := [32]byte{4}
	settlement := canonicalEmptyProgramOccupancyFixture()
	projection, err := decodeProgramOccupancy(settlement, asset)
	if err != nil || projection.ByteBatches != (Uint128{}) || projection.FeeUnits != (Uint128{}) || programOccupancyTransferRoot(projection.PaidByPayer, asset) != ([32]byte{}) {
		t.Fatalf("canonical empty Programs occupancy settlement rejected: %#v %v", projection, err)
	}
	mutated := append([]byte(nil), settlement...)
	declaredFeeLowByte := len("LXP/storage-occupancy-settlement/v3\x00") + 8 + 4 + 7*8 + 16 + 15
	mutated[declaredFeeLowByte] = 1
	if _, err := decodeProgramOccupancy(mutated, asset); err == nil {
		t.Fatalf("Programs occupancy settlement accepted a mutated fee total")
	}
	if _, err := decodeProgramOccupancy(settlement, [32]byte{}); err == nil {
		t.Fatalf("Programs occupancy settlement accepted a missing receipt asset")
	}
}

func TestProgramTerminalWrapperOrderAndUniquenessAreClosed(t *testing.T) {
	program := [32]byte{1}
	inner := []byte("LXP/program-execution-with-transfer-authority/v2\x00")
	inner = appendUint32(inner, 0)
	inner = appendUint32(inner, 0)
	inner = append(inner, make([]byte, 32)...)
	outer := []byte("LXP/program-execution-with-occupancy/v1\x00")
	outer = appendUint32(outer, uint32(len(inner)))
	outer = append(outer, inner...)
	outer = appendUint32(outer, 0)
	if _, err := decodeProgramTerminal(1, 2, outer, program, 0); err == nil {
		t.Fatalf("Programs terminal accepted producer-impossible occupancy-before-authority wrappers")
	}
}

func canonicalProgramTransferAuthorizationFixture() ([]byte, [32]byte) {
	program, principal, invocation, asset, destination := [32]byte{1}, [32]byte{2}, [32]byte{3}, [32]byte{4}, [32]byte{5}
	encoded := []byte("LayerX/programs/402LXP/transfer-set/v1\x00")
	encoded = append(encoded, program[:]...)
	encoded = append(encoded, principal[:]...)
	encoded = append(encoded, invocation[:]...)
	encoded = append(encoded, make([]byte, 8)...)
	encoded = append(encoded, 0)
	events := []byte("LayerX/programs/events/v1\x00")
	events = appendUint32(events, 0)
	encoded = appendUint32(encoded, uint32(len(events)))
	encoded = append(encoded, events...)
	encoded = appendUint64(encoded, 0)
	encoded = appendUint64(encoded, 1)
	encoded = append(encoded, make([]byte, 8)...)
	encoded = append(encoded, 0)
	encoded = append(encoded, asset[:]...)
	encoded = append(encoded, destination[:]...)
	encoded = append(encoded, make([]byte, 15)...)
	encoded = append(encoded, 7)
	encoded = append(encoded, program[:]...)
	leg := []byte{0}
	leg = append(leg, principal[:]...)
	leg = append(leg, destination[:]...)
	leg = append(leg, asset[:]...)
	leg = append(leg, make([]byte, 15)...)
	leg = append(leg, 7, 0, 1)
	return encoded, domainDigest([]byte("LXP/v1/merkle-leaf\x00"), leg)
}

func canonicalEmptyProgramOccupancyFixture() []byte {
	encoded := []byte("LXP/storage-occupancy-settlement/v3\x00")
	encoded = appendUint64(encoded, 1)
	encoded = appendUint32(encoded, 1)
	for index := 0; index < 7; index++ {
		encoded = appendUint64(encoded, uint64(index+1))
	}
	encoded = append(encoded, make([]byte, 16*4)...)
	return appendUint32(encoded, 0)
}

func canonicalProgramCallFixture() (ProgramCall, [32]byte, []byte) {
	program := [32]byte{1}
	key := [32]byte{2}
	calldata := []byte{0xaa, 0xbb}
	payload := []byte("LayerX/programs/call/v1\x00")
	payload = append(payload, program[:]...)
	payload = appendUint64(payload, 10)
	payload = append(payload, make([]byte, 15)...)
	payload = append(payload, 20)
	payload = appendUint16(payload, 1)
	payload = append(payload, 1)
	payload = appendUint32(payload, uint32(len(calldata)))
	payload = append(payload, calldata...)
	payloadHash := domainDigest([]byte("LXP/v1/payload-hash\x00"), payload)
	activity := appendUint16(nil, 2)
	activity = appendUint16(activity, 0x1001)
	activity = append(activity, 12, 1)
	activity = appendUint16(activity, 2)
	activity = append(activity, 2)
	activity = appendUint32(activity, 1)
	activity = append(activity, 3)
	activity = appendUint32(activity, 0x0009_0003)
	activity = append(activity, 4)
	activity = appendUint32(activity, 3)
	activity = append(activity, 'd', 'i', 'd')
	activity = append(activity, 5)
	activity = appendUint32(activity, 1)
	activity = append(activity, 1)
	activity = append(activity, 6)
	activity = appendUint64(activity, 1)
	activity = append(activity, 7)
	activity = appendUint64(activity, 1)
	activity = appendUint64(activity, 2)
	activity = append(activity, 8)
	activity = appendUint32(activity, 32)
	activity = append(activity, key[:]...)
	activity = append(activity, 9)
	activity = append(activity, make([]byte, 15)...)
	activity = append(activity, 30)
	activity = append(activity, 10)
	activity = appendUint32(activity, 32)
	activity = append(activity, payloadHash[:]...)
	activity = append(activity, 11)
	activity = appendUint32(activity, uint32(len(payload)))
	activity = append(activity, payload...)
	activity = append(activity, 12)
	activity = appendUint32(activity, 64)
	activity = append(activity, make([]byte, 64)...)
	return ProgramCall{ProgramID: program, Calldata: calldata, Budget: ProgramBudget{Fuel: 10, FeeLimit: NewUint128(0, 20)}, Capabilities: []ProgramCapability{ProgramStorageRead}, SignedActivity: activity}, key, activity
}

func TestProgramSDKDiscoveryCanonicalProof(t *testing.T) {
	private := ed25519.NewKeyFromSeed(bytes.Repeat([]byte{37}, ed25519.SeedSize))
	var pinned [32]byte
	copy(pinned[:], private.Public().(ed25519.PublicKey))
	for _, abi := range []uint16{ProgramAbiV1, ProgramAbiV2, ProgramAbiV3, ProgramAbiV4} {
		value := ProgramDiscovery{ProgramID: strings.Repeat("01", 32), Lifecycle: "active", Version: 2, CodeHash: strings.Repeat("02", 32), ABIVersion: abi, StateRoot: strings.Repeat("03", 32), ObservedSequence: "7", ObservedAt: "900", ValidThrough: "1100", Verification: "registry-receipt-and-current-head-verified"}
		material := []byte("LayerX/program-discovery-proof/v1\x00")
		program, _ := hex.DecodeString(value.ProgramID)
		code, _ := hex.DecodeString(value.CodeHash)
		root, _ := hex.DecodeString(value.StateRoot)
		material = append(material, program...)
		material = append(material, 1, 0, 0, 0, 2)
		material = append(material, code...)
		material = append(material, byte(abi>>8), byte(abi))
		for _, number := range []uint64{7, 900, 1100} {
			material = appendUint64(material, number)
		}
		material = append(material, root...)
		digest := sha256.Sum256(material)
		key, signature, deployment := hex.EncodeToString(pinned[:]), hex.EncodeToString(ed25519.Sign(private, digest[:])), strings.Repeat("04", 32)
		value.ReceiptDigest = hex.EncodeToString(digest[:])
		value.DiscoveryPublicKey, value.DiscoverySignature, value.DeploymentReceiptDigest = &key, &signature, &deployment
		encoded, err := json.Marshal(value)
		var decoded ProgramDiscovery
		if err != nil || decodeStrict(encoded, &decoded) != nil || !validDiscovery(decoded, value.ProgramID, 1000) {
			t.Fatalf("canonical ABI%d discovery did not decode", abi)
		}
		if verified, err := verifyProgramDiscoveryProof(decoded, pinned); err != nil || !verified {
			t.Fatalf("ABI%d genuine Ed25519 proof refused: %v", abi, err)
		}
		for name, mutate := range map[string]func(*ProgramDiscovery){
			"program":           func(v *ProgramDiscovery) { v.ProgramID = strings.Repeat("05", 32) },
			"version":           func(v *ProgramDiscovery) { v.Version++ },
			"code":              func(v *ProgramDiscovery) { v.CodeHash = strings.Repeat("06", 32) },
			"abi":               func(v *ProgramDiscovery) { v.ABIVersion = 5 },
			"sequence":          func(v *ProgramDiscovery) { v.ObservedSequence = "8" },
			"observed":          func(v *ProgramDiscovery) { v.ObservedAt = "901" },
			"expiry":            func(v *ProgramDiscovery) { v.ValidThrough = "1101" },
			"root":              func(v *ProgramDiscovery) { v.StateRoot = strings.Repeat("07", 32) },
			"digest":            func(v *ProgramDiscovery) { v.ReceiptDigest = strings.Repeat("08", 32) },
			"missing signature": func(v *ProgramDiscovery) { v.DiscoverySignature = nil },
			"bad signature":     func(v *ProgramDiscovery) { bad := strings.Repeat("00", 64); v.DiscoverySignature = &bad },
		} {
			changed := decoded
			mutate(&changed)
			if _, err := verifyProgramDiscoveryProof(changed, pinned); err == nil {
				t.Fatalf("ABI%d accepted changed %s", abi, name)
			}
		}
		wrongPin := pinned
		wrongPin[0] ^= 1
		if _, err := verifyProgramDiscoveryProof(decoded, wrongPin); err == nil {
			t.Fatal("response key replaced the independently pinned sequencer")
		}
		decoded.DiscoveryPublicKey, decoded.DiscoverySignature = nil, nil
		verified, err := verifyProgramDiscoveryProof(decoded, pinned)
		if abi == ProgramAbiV3 || abi == ProgramAbiV4 {
			if err == nil {
				t.Fatal("new ABI accepted unsigned discovery")
			}
		} else if err != nil || verified {
			t.Fatal("legacy server-only discovery was upgraded or refused")
		}
	}
}

func TestProgramSDKNativeABIPolicy(t *testing.T) {
	for _, abi := range []uint16{ProgramAbiV1, ProgramAbiV2, ProgramAbiV3, ProgramAbiV4} {
		call := NativeProgramCall{ProgramID: [32]byte{1}, GuestABI: abi, Entrypoint: "run", Resources: [7]uint64{1}}
		encoded, err := EncodeNativeProgramCall(call)
		decoded, decodeError := DecodeNativeProgramCall(encoded)
		if err != nil || decodeError != nil || decoded.GuestABI != abi {
			t.Fatalf("closed ABI%d native adapter refused", abi)
		}
		if abi == ProgramAbiV3 || abi == ProgramAbiV4 {
			request := ProgramCall{NativeCall: &call}
			if programCallHeadAdmitted(request, programHeadObservation{ABIVersion: abi}) {
				t.Fatal("unsigned head admitted new ABI")
			}
			if !programCallHeadAdmitted(request, programHeadObservation{ABIVersion: abi, Authenticated: true}) {
				t.Fatal("matched authenticated ABI head refused")
			}
			if programCallHeadAdmitted(request, programHeadObservation{ABIVersion: ProgramAbiV2, Authenticated: true}) {
				t.Fatal("different ABI head admitted")
			}
		}
	}
	for _, abi := range []uint16{0, 6, 65535} {
		if SupportsProgramGuestAbi(abi) {
			t.Fatalf("unknown ABI%d admitted", abi)
		}
		if _, err := EncodeNativeProgramCall(NativeProgramCall{ProgramID: [32]byte{1}, GuestABI: abi, Entrypoint: "run"}); err == nil {
			t.Fatalf("unknown ABI%d encoded", abi)
		}
	}
}

func TestProgramSDKInterfaceNativeBindingAndBound(t *testing.T) {
	_, payload, _, _ := lifecycleFixture(t, "deploy")
	deployment, err := DecodeNativeProgramDeploy(payload)
	if err != nil || len(deployment.Interface) == 0 {
		t.Fatal("genuine C deployment interface fixture required")
	}
	encoded := hex.EncodeToString(deployment.Interface)
	digest := sha256.Sum256(deployment.Interface)
	digestText := hex.EncodeToString(digest[:])
	value := ProgramInterface{ProgramID: hex.EncodeToString(deployment.ProgramID[:]), Version: 1, CodeHash: hex.EncodeToString(deployment.NewHash[:]), ABIVersion: deployment.GuestABI, Interface: &encoded, InterfaceDigest: &digestText, ReceiptDigest: strings.Repeat("04", 32), StateRoot: strings.Repeat("05", 32), ObservedSequence: "1", ObservedAt: "1", ValidThrough: "3", Source: ProgramSource{Status: "unpublished"}, Verification: "deployment-interface-and-current-head-verified"}
	if !validProgramInterface(value, value.ProgramID, 2) {
		t.Fatal("canonical C deployment interface refused")
	}
	changed := value
	changed.CodeHash = strings.Repeat("06", 32)
	if validProgramInterface(changed, changed.ProgramID, 2) {
		t.Fatal("interface code hash mismatch accepted")
	}
	changed = value
	changed.ABIVersion = ProgramAbiV3
	if validProgramInterface(changed, changed.ProgramID, 2) {
		t.Fatal("interface ABI mismatch accepted")
	}
	oversized := append(append([]byte{}, deployment.Interface...), make([]byte, 953-len(deployment.Interface))...)
	oversizedText := hex.EncodeToString(oversized)
	oversizedDigest := sha256.Sum256(oversized)
	oversizedDigestText := hex.EncodeToString(oversizedDigest[:])
	changed = value
	changed.Interface, changed.InterfaceDigest = &oversizedText, &oversizedDigestText
	if validProgramInterface(changed, changed.ProgramID, 2) {
		t.Fatal("oversized interface accepted despite matching digest")
	}
}

func TestProgramTerminalV5NativeCorpus(t *testing.T) {
	path := os.Getenv("PAXEER_X_PROGRAM_TERMINAL_V5_CORPUS")
	if path == "" {
		t.Fatal("real native terminal-v5 signed corpus required")
	}
	raw, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	var corpus struct {
		SourceRevision   string `json:"source_revision"`
		TrustedSequencer string `json:"trusted_sequencer_public_key_hex"`
		Cases            []struct {
			Name      string                   `json:"name"`
			GuestABI  uint16                   `json:"guest_abi"`
			Outcome   string                   `json:"outcome"`
			Execution ProgramExecutionDocument `json:"execution"`
			Activity  string                   `json:"signed_activity_hex"`
			Sequencer string                   `json:"sequencer_public_key_hex"`
			Canonical string                   `json:"canonical_receipt_hex"`
			Digest    string                   `json:"receipt_digest_hex"`
			Terminal  string                   `json:"terminal_payload_hex"`
			Graph     string                   `json:"call_graph_hex"`
			Program   string                   `json:"program_id_hex"`
			Authority receiptFixtureAuthority  `json:"authorized_batch"`
		} `json:"cases"`
	}
	if err := json.Unmarshal(raw, &corpus); err != nil {
		t.Fatal(err)
	}
	if corpus.TrustedSequencer != "b4f05aee172965774743f4cd7de4c3621c9e36fd77af7139aafec25eb3fb3360" {
		t.Fatal("native corpus sequencer differs from independently pinned producer")
	}
	if len(corpus.SourceRevision) != 40 || len(corpus.Cases) != 10 {
		t.Fatal("complete native source revision and ten ABI3/4 cases required")
	}
	if _, err := hex.DecodeString(corpus.SourceRevision); err != nil {
		t.Fatal("invalid native source revision")
	}
	seen := make(map[string]bool)
	for _, vector := range corpus.Cases {
		key := strconv.Itoa(int(vector.GuestABI)) + ":" + vector.Outcome
		if vector.GuestABI != ProgramAbiV3 && vector.GuestABI != ProgramAbiV4 || seen[key] {
			t.Fatalf("invalid or duplicate native case %s", key)
		}
		seen[key] = true
		t.Run(vector.Name, func(t *testing.T) {
			if fixture32(t, corpus.TrustedSequencer) != fixture32(t, vector.Authority.SequencerPublicKeyHex) {
				t.Fatal("native sequencer pin differs from authorized batch")
			}
			canonical := fixtureBytes(t, vector.Canonical)
			decoded, err := decodeProtocolReceipt(canonical)
			if err != nil || decoded.protocol.ProgramOutcome == nil {
				t.Fatalf("actual native signed receipt: %v", err)
			}
			digest := domainDigest(receiptDomain, decoded.unsigned)
			if !ed25519.Verify(fixtureBytes(t, corpus.TrustedSequencer), digest[:], decoded.signature[:]) {
				t.Fatal("native receipt signature is invalid")
			}
			if digest != fixture32(t, vector.Digest) {
				t.Fatal("native receipt digest differs from signed canonical bytes")
			}
			receiptOutcome := decoded.protocol.ProgramOutcome
			actualTerminal := fixtureBytes(t, vector.Terminal)
			actualInner, err := unwrapAppliedProgramTerminal(actualTerminal, *receiptOutcome)
			if err != nil {
				t.Fatal(err)
			}
			projection, err := decodeProgramTerminalProfile(receiptOutcome.TerminalKind, receiptOutcome.ABIVersion, actualInner, fixture32(t, vector.Program), receiptOutcome.ResultCode, true)
			if err != nil {
				t.Fatal(err)
			}
			execution := ProgramExecutionDocument{
				ActivityID: hex.EncodeToString(decoded.protocol.ActivityID[:]), ProgramID: vector.Program,
				ModuleVersion: decoded.protocol.ModuleVersion, GuestABIVersion: receiptOutcome.ABIVersion,
				Receipt: vector.Canonical, ReceiptDigest: hex.EncodeToString(digest[:]),
				TerminalPayload: vector.Terminal, CallGraph: vector.Graph,
				ResultCode: receiptOutcome.ResultCode, Outcome: projection.Outcome,
			}
			if execution.GuestABIVersion != vector.GuestABI {
				t.Fatal("native signed receipt guest ABI mismatch")
			}
			signed := fixtureBytes(t, vector.Activity)
			payload := programV5CorpusCallPayload(t, signed)
			call, err := DecodeNativeProgramCall(payload)
			if err != nil || call.GuestABI != vector.GuestABI || call.ProgramID != fixture32(t, vector.Program) {
				t.Fatal("native signed request ABI or program mismatch")
			}
			binding, err := bindNativeProgramActivity(3, payload, signed)
			if err != nil || binding.ActivityID != fixture32(t, execution.ActivityID) {
				t.Fatal("native signed activity identity mismatch")
			}
			verified, err := VerifyProgramReceipt(execution, 3)
			if err != nil {
				t.Fatalf("real native %s verification: %v", key, err)
			}
			outcome := verified.Verification.Receipt.ProgramOutcome
			if outcome == nil || outcome.ABIVersion != call.GuestABI {
				t.Fatal("signed receipt ABI differs from request")
			}
			terminal, graph := fixtureBytes(t, vector.Terminal), fixtureBytes(t, vector.Graph)
			inner, err := unwrapAppliedProgramTerminal(terminal, *outcome)
			if err != nil {
				t.Fatal(err)
			}
			if vector.Outcome == "success" || vector.Outcome == "failure" || vector.Outcome == "resource" {
				v5 := []byte("LXP/program-execution/v5\x00")
				at := bytes.Index(inner, v5)
				if at < 0 {
					t.Fatal("native execution lacks v5 domain")
				}
				old := append([]byte(nil), inner...)
				copy(old[at:], []byte("LXP/program-execution/v4\x00"))
				if _, err := decodeProgramTerminalProfile(outcome.TerminalKind, outcome.ABIVersion, old, call.ProgramID, outcome.ResultCode, true); err == nil {
					t.Fatal("historical v4 admitted ABI3/4")
				}
				for _, abi := range []uint16{0, 1, 2, 5, 65535} {
					if _, err := decodeProgramTerminalProfile(outcome.TerminalKind, abi, inner, call.ProgramID, outcome.ResultCode, true); err == nil {
						t.Fatalf("v5 admitted unsupported or mismatched ABI %d", abi)
					}
				}
				for _, mutate := range []func(*ProgramReceiptOutcome){
					func(o *ProgramReceiptOutcome) { o.RuntimeVersion++ },
					func(o *ProgramReceiptOutcome) { o.FeeScheduleVersion++ },
					func(o *ProgramReceiptOutcome) { o.MeteringScheduleVersion++ },
					func(o *ProgramReceiptOutcome) { o.CPUFuel++ },
					func(o *ProgramReceiptOutcome) { o.MemoryBytes++ },
					func(o *ProgramReceiptOutcome) { o.StorageReadBytes++ },
					func(o *ProgramReceiptOutcome) { o.StorageWriteBytes++ },
					func(o *ProgramReceiptOutcome) { o.OutputValues++ },
					func(o *ProgramReceiptOutcome) { o.OutputBytes++ },
					func(o *ProgramReceiptOutcome) { o.FeeUnits = NewUint128(0, 18446744073709551615) },
				} {
					changedReceipt := verified.Verification.Receipt
					changedOutcome := *outcome
					mutate(&changedOutcome)
					changedReceipt.ProgramOutcome = &changedOutcome
					if _, _, err := verifyProgramTerminal(execution, changedReceipt, terminal, graph, nil); err == nil {
						t.Fatal("v5 admitted changed signed accounting projection")
					}
				}
				wrongProgram := call.ProgramID
				wrongProgram[0] ^= 1
				if _, err := decodeProgramTerminalProfile(outcome.TerminalKind, outcome.ABIVersion, inner, wrongProgram, outcome.ResultCode, true); err == nil {
					t.Fatal("v5 admitted wrong program")
				}
			}
			for length := 0; length < len(terminal); length++ {
				if _, _, err := verifyProgramTerminal(execution, verified.Verification.Receipt, terminal[:length], graph, nil); err == nil {
					t.Fatalf("accepted terminal truncation %d", length)
				}
			}
			if _, _, err := verifyProgramTerminal(execution, verified.Verification.Receipt, append(append([]byte{}, terminal...), 0), graph, nil); err == nil {
				t.Fatal("accepted trailing terminal byte")
			}
			badGraph := append([]byte(nil), graph...)
			badGraph[0] ^= 1
			if _, _, err := verifyProgramTerminal(execution, verified.Verification.Receipt, terminal, badGraph, nil); err == nil {
				t.Fatal("accepted changed graph")
			}
			unpinnedExecution := execution
			unpinnedExecution.ReceiptKeys.Pins = append([]ReceiptKey(nil), execution.ReceiptKeys.Pins...)
			for index := range unpinnedExecution.ReceiptKeys.Pins {
				unpinnedExecution.ReceiptKeys.Pins[index].PublicKey[0] ^= 1
			}
			if _, err := VerifyProgramReceipt(unpinnedExecution, 3); err == nil {
				t.Fatal("accepted unpinned sequencer")
			}
			bad := execution
			bad.GuestABIVersion = ProgramAbiV3 + ProgramAbiV4 - vector.GuestABI
			if _, err := VerifyProgramReceipt(bad, 3); err == nil {
				t.Fatal("accepted request and receipt ABI mismatch")
			}
			bad = execution
			bad.ModuleVersion = 3
			if _, err := VerifyProgramReceipt(bad, 3); err == nil {
				t.Fatal("accepted module mismatch")
			}
			changed := append([]byte(nil), canonical...)
			changed[len(changed)-1] ^= 1
			bad = execution
			bad.Receipt = hex.EncodeToString(changed)
			if _, err := VerifyProgramReceipt(bad, 3); err == nil {
				t.Fatal("accepted receipt signature mutation")
			}
		})
	}
	for _, abi := range []uint16{ProgramAbiV3, ProgramAbiV4} {
		for _, outcome := range []string{"success", "failure", "resource", "callback", "settlement"} {
			if !seen[strconv.Itoa(int(abi))+":"+outcome] {
				t.Fatalf("missing actual native ABI%d %s case", abi, outcome)
			}
		}
	}
}

func programV5CorpusCallPayload(t *testing.T, signed []byte) []byte {
	t.Helper()
	d := wireDecoder{value: signed}
	_ = d.u16()
	_ = d.u16()
	_ = d.u8()
	_ = d.u8()
	_ = d.u16()
	_ = d.u8()
	_ = d.u32()
	_ = d.u8()
	_ = d.u32()
	_ = d.u8()
	_ = d.bounded(255)
	_ = d.u8()
	_ = d.bounded(524288)
	_ = d.u8()
	_ = d.u64()
	_ = d.u8()
	_ = d.u64()
	_ = d.u64()
	_ = d.u8()
	_ = d.array32()
	_ = d.u8()
	_ = d.u128()
	_ = d.u8()
	_ = d.array32()
	_ = d.u8()
	payload := d.bounded(524288)
	if d.failed || len(payload) == 0 {
		t.Fatal("invalid real signed CALL")
	}
	return payload
}
